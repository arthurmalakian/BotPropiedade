package br.ufrn.imd.local.Observers;

import br.ufrn.imd.local.bot.Item;

public interface IObserver {
    public void update(Item self);
}
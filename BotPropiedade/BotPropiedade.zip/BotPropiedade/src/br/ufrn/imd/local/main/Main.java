package br.ufrn.imd.local.main;

import br.ufrn.imd.local.bot.Bot;

public class Main {
    public static void main(String[] args) {
        Bot bot = new Bot("943849281:AAHnmuEq2WZ3EVy65ZWhNfvVj76wf7zpA_A");
        bot.run();
    }
    
}

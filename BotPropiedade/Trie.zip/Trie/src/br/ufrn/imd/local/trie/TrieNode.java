package br.ufrn.imd.local.trie;

import java.util.HashMap;
import java.util.Map;

public class TrieNode {
	
	private Map<Character,TrieNode> children;
	private boolean endOfWord;
    private TrieNode parent;
    private boolean checked = false;
	
	public TrieNode() {
		this.children =  new HashMap<Character, TrieNode>();
		this.endOfWord = false;
	}
	
	public Map<Character,TrieNode> getChildren() {
		return children;
	}
	public boolean isEndOfWord() {
		return endOfWord;
	}
	public void setendOfWord(boolean value) {
		this.endOfWord = value;
	}

 
    public TrieNode getParent() {
        return parent;
    }

    public void setParent(TrieNode parent) {
        this.parent = parent;
    }

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
        
}

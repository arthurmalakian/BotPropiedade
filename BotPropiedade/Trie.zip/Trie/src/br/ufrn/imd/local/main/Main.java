package br.ufrn.imd.local.main;

import br.ufrn.imd.local.dictionary.Dictionary;

public class Main {

	public static void main(String[] args){
		// TODO Auto-generated method stub
		Dictionary dictionary = new Dictionary(args[0]);
		//dictionary.SearchPrefix(args[1]);
                System.out.println("Programa incompleto.");
	}

}

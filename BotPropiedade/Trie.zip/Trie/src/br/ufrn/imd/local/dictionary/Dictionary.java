package br.ufrn.imd.local.dictionary;

import br.ufrn.imd.local.trie.Trie;
import br.ufrn.imd.local.trie.TrieNode;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class Dictionary {
    public Trie dictionary = new Trie();
    
    public Dictionary(String path) {
        
        File f;
	Scanner scan = null;	
	try {
            f = new File(path);
            scan = new Scanner(f);
        }catch(FileNotFoundException fe) {
                System.out.println("Arquivo não encontrado");
                return;
        }
	scan.useDelimiter("[^A-Za-z]+");
	while (scan.hasNextLine()) {
            dictionary.insert(scan.nextLine());
	}
    }
   
    public ArrayList<String> SearchPrefix(String prefix) {
    	dictionary.lendosubarvore(dictionary.getSubtree(prefix));
    	return null;
    }
    
}